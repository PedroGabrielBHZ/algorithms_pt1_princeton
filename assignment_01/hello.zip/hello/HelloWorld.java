/* *****************************************************************************
 *  Name:              Pedro Gabriel Amorim Soares
 *  Coursera User ID:  ?
 *  Last modified:     November 04, 2024
 **************************************************************************** */

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World");
    }
}
